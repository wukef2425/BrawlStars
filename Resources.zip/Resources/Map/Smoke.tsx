<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="Smoke" tilewidth="64" tileheight="64" tilecount="208" columns="16">
    <image source="Smoke.png" width="1058" height="849"/>
</tileset>
