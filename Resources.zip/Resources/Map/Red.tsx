<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="Red" tilewidth="64" tileheight="64" tilecount="2" columns="1">
 <image source="Red.png" width="126" height="137"/>
</tileset>
