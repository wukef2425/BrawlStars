<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="Basic-SnowFiled" tilewidth="64" tileheight="64" tilecount="420" columns="28">
 <image source="Basic-SnowFiled.png" width="1800" height="960"/>
</tileset>
